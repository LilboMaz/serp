# SERP Tracker - VPS Kurulum Rehberi

Telegram üzerinden domain sıralama takibi yapan bot. Kendi VPS sunucunuzda çalışır.

## 🚀 Özellikler

- 🤖 Telegram Bot komutları ile yönetim
- 🇹🇷 Türkiye Google sıralama sorgusu (Serper.dev API)
- ⏱️ Ayarlanabilir otomatik kontrol (10-1440 dakika)
- 💾 JSON dosyasında domain/keyword saklama
- 📝 Detaylı log dosyası
- 🔄 PM2 ile sürekli çalışma ve otomatik restart

## 📋 Gereksinimler

- Node.js 18+
- Ubuntu/Debian VPS (tavsiye: en az 1GB RAM)
- Serper.dev API anahtarı
- Telegram Bot Token

## 🔧 Kurulum

### 1. VPS Hazırlığı

```bash
# Sunucuyu güncelle
sudo apt update && sudo apt upgrade -y

# Node.js ve npm kur
sudo apt install -y nodejs npm git

# Node.js versiyonunu kontrol et (18+ olmalı)
node --version

# PM2 kurulumu
sudo npm install -g pm2
```

### 2. Proje Kurulumu

```bash
# Proje dizinine git (veya klonla)
cd /opt
# git clone <repo-url> serp-tracker  # Eğer repo'dan çekiyorsan

# Dizine gir
cd serp-tracker

# Bağımlılıkları yükle
npm install
```

### 3. Çevre Değişkenleri Ayarı

```bash
# .env dosyasını oluştur
cp .env.example .env

# Düzenle
nano .env
```

`.env` içeriği:
```env
SERPER_API_KEY=your_serper_api_key_here
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
TELEGRAM_CHAT_ID=your_telegram_chat_id_here
```

**Değerleri nasıl alırsınız:**

- **SERPER_API_KEY**: [serper.dev](https://serper.dev/) sitesinden ücretsiz kaydolun
- **TELEGRAM_BOT_TOKEN**: Telegram'da [@BotFather](https://t.me/botfather) ile bot oluşturun
- **TELEGRAM_CHAT_ID**: 
  - Kişisel kullanım: [@userinfobot](https://t.me/userinfobot) mesaj atın
  - Grup kullanımı: Gruba botu ekleyin, `/start` yazın

### 4. İlk Test

```bash
# Test için çalıştır
npm run server

# Çalışıyorsa Ctrl+C ile durdur
```

### 5. PM2 ile Sürekli Çalıştırma

```bash
# PM2 ile başlat
pm2 start ecosystem.config.js

# Durum kontrolü
pm2 status

# Otomatik başlatma ayarı
pm2 startup
# Çıkan komutu kopyalayıp çalıştırın (sudo ile)

# Mevcut durumu kaydet
pm2 save
```

## 💬 Telegram Komutları

| Komut | Açıklama | Örnek |
|-------|----------|-------|
| `/start` | Yardım menüsü | `/start` |
| `/ekle` | Domain ve keyword ekle | `/ekle example.com seo,tasarım` |
| `/kontrol` | Sıralama kontrol et | `/kontrol example.com` |
| `/listele` | Tüm domainleri listele | `/listele` |
| `/sil` | Domain sil | `/sil example.com` |
| `/aralik` | Otomatik kontrol dakikası | `/aralik 60` |
| `/otomatik` | Otomatik kontrol aç/kapat | `/otomatik aç` veya `/otomatik kapat` |
| `/durum` | Bot durumunu göster | `/durum` |

## 📊 Kullanım Örneği

```
/ekle benimsite.com seo,web tasarım,digital pazarlama
✅ benimsite.com eklendi!
🔑 3 keyword
🔄 Otomatik kontrole dahil edildi

/kontrol benimsite.com
⏳ benimsite.com sorgulanıyor...

🔍 benimsite.com Sıralama Sonuçları
🇹🇷 Türkiye - Google

🥇 seo → Sıra #2
🔵 web tasarım → Sıra #7
⚪ digital pazarlama → Sıra #15

📊 3/3 keyword bulundu
```

## 🔍 Log İzleme

```bash
# Canlı log takibi
pm2 logs serp-tracker

# Sadece hata logları
pm2 logs serp-tracker --err

# Log dosyaları
tail -f logs/combined.log
tail -f logs.txt
```

## 🛠️ Yönetim Komutları

```bash
# Yeniden başlat
pm2 restart serp-tracker

# Durdur
pm2 stop serp-tracker

# Başlat
pm2 start serp-tracker

# Sil ve yeniden oluştur
pm2 delete serp-tracker
pm2 start ecosystem.config.js

# Monitör (canlı izleme)
pm2 monit

# Tüm logları temizle
pm2 flush
```

## 📁 Dosya Yapısı

```
serp-tracker/
├── server.js              # Ana uygulama
├── ecosystem.config.js    # PM2 konfigürasyonu
├── config.json            # Domain/keyword verileri
├── logs.txt               # İşlem logları
├── logs/                  # PM2 logları
│   ├── err.log
│   ├── out.log
│   └── combined.log
├── .env                   # API anahtarları (git'e push etme!)
├── .env.example           # Örnek .env dosyası
└── package.json
```

## ⚙️ Ayarlar (config.json)

Bot otomatik olarak `config.json` oluşturur:

```json
{
  "domains": [
    {
      "domain": "example.com",
      "keywords": ["seo", "web tasarım"],
      "addedAt": "2025-01-20T10:00:00Z",
      "lastChecked": "2025-01-20T15:30:00Z",
      "checkCount": 5
    }
  ],
  "settings": {
    "autoCheck": true,
    "intervalMinutes": 60
  }
}
```

## 🔒 Güvenlik

- `.env` dosyasını **asla** GitHub'a push etmeyin
- `config.json` domain bilgilerini içerir, yedekleyin
- API anahtarlarını kimseyle paylaşmayın

## 🐛 Sorun Giderme

### Bot çalışmıyor
```bash
pm2 logs serp-tracker --lines 50
```

### API hatası
- Serper.dev API anahtarını kontrol edin
- API limitini kontrol edin (ücretsiz plan: 100 sorgu/ay)

### Telegram mesaj gitmiyor
- Bot token doğru mu?
- Chat ID doğru mu?
- Bot grupta admin mi?

### Port çakışması
```bash
# 3000 portunu kullananı bul
sudo lsof -i :3000

# Öldür
sudo kill -9 <PID>
```

## 📞 Destek

Sorun yaşarsanız:
1. Logları kontrol edin: `pm2 logs`
2. Config dosyasını kontrol edin
3. API anahtarlarını yenileyin

## 📝 Güncelleme

```bash
cd /opt/serp-tracker

# Yeni değişiklikleri çek
git pull

# Bağımlılıkları güncelle
npm install

# Yeniden başlat
pm2 restart serp-tracker
```
